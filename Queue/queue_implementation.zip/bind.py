import os
import sys

argList = sys.argv
argList.pop(0)

argList.reverse()
objCmd = 'gcc -Wall -Wextra -std=c11 -c'
cmpCmd = 'gcc'

# Makes Object File
for i in argList:
    os.system(f'{objCmd} {i}')

# Makes Executable File:
exeCmd = f'{cmpCmd} {argList[0][:-1] + "o"} {argList[1][:-1] + "o"} -o {argList[1][:-2]}'
os.system(exeCmd)


# Remove Object File
for i in argList:
    os.system(f'del {i[:-1]+"o"}')


os.system(f'.\{argList[1][:-2]}.exe')